# Jakarta Batch Demo (JBeret SE + Weld SE)

本示例演示在 **纯 Java SE** 环境下运行 Jakarta Batch（JSR 352 / Jakarta Batch 2.x）。
- 批处理运行时：JBeret SE
- 依赖注入：Weld SE（用于 @Named 批处理构件发现）
- 作业方式：基于 chunk 的 CSV -> CSV 转换（转大写），带 checkpoint

## 快速开始

```bash
# 1) 打包 fat-jar
mvn -q -e -DskipTests package

# 2) 运行作业（默认运行 csvJob）
java -jar target/jakarta-batch-demo-1.0.0.jar

# 3) 查看输出
ls -l target/output/output.csv
cat target/output/output.csv
```

> 你也可以通过传参运行指定作业名：
```bash
java -jar target/jakarta-batch-demo-1.0.0.jar csvJob
```

## 结构说明
- `src/main/resources/META-INF/batch-jobs/csvJob.xml`：作业定义
- `CsvItemReader`：按行读取 CSV，支持断点续跑（checkpoint）
- `UppercaseProcessor`：把每列转为大写
- `CsvItemWriter`：输出到 `target/output/output.csv`（自动创建目录）
- `DemoLauncher`：程序入口，启动 BatchRuntime 并运行作业

## 配置项（可在 job XML 的 <properties> 中修改）
- `input`：输入 CSV 的类路径位置，默认 `input/input.csv`
- `output`：输出 CSV 的相对位置，默认 `output/output.csv`
- `delimiter`：分隔符，默认 `,`
- `header`：是否有表头，默认 `true`（有表头时首行会被 reader 跳过）

## 进阶：在应用服务器中运行（WildFly / Payara / etc.）
- 替换 `jberet-se` 为应用服务器提供的 batch 实现（WildFly 内置 JBeret）。
- 把 `batch-jobs` 放在 `META-INF` 下；保留 `@Named` 构件并打包成 `war/ear` 部署。
- 使用 CLI 或管理控制台启动作业或观察执行状态。

## 常见问题
- 若 fat-jar 运行报错，确认 JDK 版本（建议 17+）以及网络可下载依赖。
- 需要自定义 readers/writers 的编码、列映射，可在 Processor 中做解析与重组。

祝你使用顺利！
