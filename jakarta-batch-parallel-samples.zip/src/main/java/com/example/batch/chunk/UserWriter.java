package com.example.batch.chunk;

import com.example.batch.dto.UserDTO;
import jakarta.batch.api.chunk.ItemWriter;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;
import javax.sql.DataSource;
import java.sql.*;

@Named("UserWriter")
public class UserWriter implements ItemWriter {
    @jakarta.inject.Inject private DataSource ds;
    private Connection conn;

    @Override public void open(Serializable checkpoint) throws Exception {
        conn = ds.getConnection();
        conn.setAutoCommit(false);
    }

    @Override public void writeItems(List<Object> items) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
            "INSERT INTO user_profile(id, name, email) VALUES(?,?,?) " +
            "ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, email = EXCLUDED.email")) {
            for (Object o : items) {
                UserDTO u = (UserDTO) o;
                ps.setLong(1, u.id());
                ps.setString(2, u.name());
                ps.setString(3, u.email());
                ps.addBatch();
            }
            ps.executeBatch();
        }
        conn.commit();
    }

    @Override public void close() throws Exception { if (conn!=null) conn.close(); }
    @Override public Serializable checkpointInfo() { return null; }
}
