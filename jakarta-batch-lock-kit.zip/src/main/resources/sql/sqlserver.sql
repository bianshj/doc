-- SQL Server DDL for DB-backed mutex
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='batch_mutex')
BEGIN
    CREATE TABLE dbo.batch_mutex (
      job_name     varchar(128) NOT NULL PRIMARY KEY,
      locked_at    datetime2     NOT NULL DEFAULT SYSUTCDATETIME(),
      heartbeat_at datetime2     NOT NULL DEFAULT SYSUTCDATETIME(),
      owner_node   varchar(128)  NOT NULL,
      exec_id      bigint        NULL
    );
END
GO

-- TTL cleanup: 10 minutes
DELETE FROM dbo.batch_mutex
 WHERE heartbeat_at < DATEADD(minute, -10, SYSUTCDATETIME());
