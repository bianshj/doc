package com.example.batch.mapper;

import jakarta.batch.api.partition.PartitionMapper;
import jakarta.batch.api.partition.PartitionPlan;
import jakarta.inject.Named;

@Named("UserPartitionMapper")
public class UserPartitionMapper implements PartitionMapper {
    @Override
    public PartitionPlan mapPartitions() {
        final int partitions = 4;
        final String[][] props = new String[partitions][2];
        long totalStart = 1L, totalEnd = 1_000_000L;
        long size = (totalEnd - totalStart + 1) / partitions;

        for (int i = 0; i < partitions; i++) {
            long start = totalStart + i * size;
            long end   = (i == partitions - 1) ? totalEnd : (start + size - 1);
            props[i][0] = "startId=" + start;
            props[i][1] = "endId=" + end;
        }

        final class Plan extends jakarta.batch.api.partition.PartitionPlan {
            @Override public int getPartitions() { return partitions; }
            @Override public String[] getPartitionProperties(int i) { return props[i]; }
            @Override public boolean getPartitionsOverride() { return true; }
        }
        return new Plan();
    }
}
