package demo.batch.B;

import jakarta.batch.api.AbstractBatchlet;
import jakarta.batch.api.BatchProperty;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.nio.file.*;
import java.util.Arrays;
import java.util.List;

/**
 * 方案B：每个分区写自己的临时文件，结束后由 Reducer 单线程合并。
 */
@Dependent
@Named("myBatchlet")
public class MyBatchlet extends AbstractBatchlet {

    @Inject @BatchProperty(name = "partitionNumber")
    private String partNo;

    @Override
    public String process() throws Exception {
        int idx = Integer.parseInt(partNo);
        Path tmp = Paths.get("data/out/tmp/result_part_" + idx + ".txt");
        Files.createDirectories(tmp.getParent());
        List<String> lines = Arrays.asList(
                "part=" + idx + ", line=1",
                "part=" + idx + ", line=2"
        );
        Files.write(tmp, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return "COMPLETED";
    }
}
