package com.example.batch;

import jakarta.batch.operations.JobOperator;
import jakarta.batch.runtime.BatchRuntime;
import java.util.Properties;

public class BatchMain {
    public static void main(String[] args) {
        Properties props = new Properties();
        props.setProperty("input", "data/input-items.csv");
        props.setProperty("table", "dbo.Items");
        props.setProperty("jdbc.url", "jdbc:sqlserver://localhost:1433;encrypt=true;trustServerCertificate=true;databaseName=YourDb");
        props.setProperty("jdbc.user", "sa");
        props.setProperty("jdbc.password", "YourStrong!Passw0rd");
        props.setProperty("chunkSize", "200");

        JobOperator jo = BatchRuntime.getJobOperator();
        long execId = jo.start("import-items", props);
        System.out.println("Job started. executionId = " + execId);
    }
}
