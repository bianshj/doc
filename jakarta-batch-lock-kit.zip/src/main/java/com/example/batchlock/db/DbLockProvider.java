package com.example.batchlock.db;

import com.example.batchlock.JobLock;
import com.example.batchlock.LockProvider;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Optional;

/**
 * Database-backed lock provider. Cluster-safe.
 * Requires table `batch_mutex` with the columns used below (see resources/sql).
 */
public class DbLockProvider implements LockProvider {

    private final DataSource ds;

    public DbLockProvider(DataSource dataSource) {
        this.ds = dataSource;
    }

    @Override
    public Optional<JobLock> tryAcquire(String jobName, String owner, Long execId) throws Exception {
        Connection conn = ds.getConnection();
        boolean ok = false;
        try {
            boolean orig = conn.getAutoCommit();
            conn.setAutoCommit(true);
            String sql = "INSERT INTO batch_mutex(job_name, locked_at, heartbeat_at, owner_node, exec_id) " +
                         "VALUES (?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, jobName);
                ps.setString(2, owner);
                if (execId == null) ps.setNull(3, Types.BIGINT); else ps.setLong(3, execId);
                ps.executeUpdate();
                ok = true;
            } catch (SQLException e) {
                // Unique constraint violation implies already locked.
                ok = false;
            } finally {
                conn.setAutoCommit(orig);
            }

            if (!ok) { conn.close(); return Optional.empty(); }

            return Optional.of(new DbJobLock(conn, jobName));
        } catch (Exception e) {
            try { conn.close(); } catch (Exception ignore) {}
            throw e;
        }
    }

    @Override
    public void forceUnlock(String jobName) throws Exception {
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM batch_mutex WHERE job_name=?")) {
            ps.setString(1, jobName);
            ps.executeUpdate();
        }
    }
}
