package demo.batch.C.c3_dist_lock;

import demo.batch.C.common.FileAppendPaths;
import jakarta.batch.api.AbstractBatchlet;
import jakarta.batch.api.BatchProperty;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

/**
 * 方案C-3：分布式锁骨架。将 acquire/release 替换为你的实现：
 * - 数据库 Advisory Lock（PostgreSQL pg_try_advisory_lock / MySQL GET_LOCK）
 * - Redis 锁（Redisson RLock.tryLock）
 */
@Dependent
@Named("myBatchlet_DistLock")
public class MyBatchlet_DistLockSkeleton extends AbstractBatchlet {

    @Inject @BatchProperty(name = "partitionNumber")
    private String partNo;

    @Inject
    private DistLock distLock; // 需要你提供实现

    @Override
    public String process() throws Exception {
        String lockKey = "file-append:" + FileAppendPaths.output().toAbsolutePath();
        if (!distLock.tryAcquire(lockKey, 5000)) { // 5s 超时
            throw new IllegalStateException("dist lock timeout: " + lockKey);
        }
        try {
            var out = FileAppendPaths.output();
            java.nio.file.Files.createDirectories(out.getParent());
            var lines = java.util.Arrays.asList(
                    "part=" + partNo + ", line=1",
                    "part=" + partNo + ", line=2"
            );
            try (var w = java.nio.file.Files.newBufferedWriter(out,
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND)) {
                for (String s : lines) {
                    w.write(s);
                    w.newLine();
                }
            }
        } finally {
            distLock.release(lockKey);
        }
        return "COMPLETED";
    }

    public interface DistLock {
        boolean tryAcquire(String key, long timeoutMs) throws Exception;
        void release(String key) throws Exception;
    }
}
