package com.example.batch;

import jakarta.batch.api.chunk.ItemProcessor;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

/**
 * Simple processor: convert all fields to upper-case.
 */
@Named("upperProcessor")
@Dependent
public class UppercaseProcessor implements ItemProcessor {

    @Override
    public Object processItem(Object item) throws Exception {
        String line = (String) item;
        String[] parts = line.split(",", -1);
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].toUpperCase();
        }
        return String.join(",", parts);
    }
}
