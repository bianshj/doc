package demo.batch.A;

import jakarta.batch.api.partition.PartitionCollector;
import jakarta.batch.runtime.context.StepContext;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

/**
 * Collector 在分区线程上被调用，用于把该分区的产出返回给 Analyzer。
 */
@Dependent
@Named("myCollector")
public class MyCollector implements PartitionCollector {

    @Inject
    private StepContext stepCtx;

    @Override
    public Serializable collectPartitionData() {
        @SuppressWarnings("unchecked")
        List<String> lines = (List<String>) stepCtx.getTransientUserData();
        return (Serializable) lines; // 可为 null
    }
}
