package com.example.batch;

import jakarta.batch.api.chunk.AbstractItemReader;
import jakarta.batch.api.chunk.CheckpointAlgorithm;
import jakarta.batch.api.chunk.ItemReader;
import jakarta.batch.api.chunk.listener.RetryReadListener;
import jakarta.batch.api.chunk.listener.SkipReadListener;
import jakarta.batch.api.chunk.listener.ItemReadListener;
import jakarta.batch.api.chunk.listener.RetryProcessListener;
import jakarta.batch.api.chunk.listener.SkipProcessListener;
import jakarta.batch.runtime.context.JobContext;
import jakarta.batch.runtime.context.StepContext;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.io.Serializable;

/**
 * A simple CSV reader with checkpoint support.
 * Reads line by line, returns String for each line (skips optional header).
 */
@Named("csvReader")
@Dependent
public class CsvItemReader extends AbstractItemReader {
    @Inject JobContext jobCtx;
    @Inject StepContext stepCtx;

    private BufferedReader br;
    private String delimiter = ",";
    private boolean header = true;
    private long lineNumber = 0; // current line index in file
    private long startFrom = 0;  // resume position from checkpoint

    public static class ReaderCheckpoint implements Serializable {
        private static final long serialVersionUID = 1L;
        long lineNumber;
        ReaderCheckpoint(long lineNumber) { this.lineNumber = lineNumber; }
    }

    @Override
    public void open(Serializable checkpoint) throws Exception {
        Properties jobProps = jobCtx.getProperties();
        String input = jobProps.getProperty("input", "input/input.csv");
        this.delimiter = jobProps.getProperty("delimiter", ",");
        this.header = Boolean.parseBoolean(jobProps.getProperty("header", "true"));

        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(input);
        if (is == null) {
            throw new FileNotFoundException("Input resource not found on classpath: " + input);
        }
        this.br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

        if (checkpoint != null) {
            ReaderCheckpoint cp = (ReaderCheckpoint) checkpoint;
            this.startFrom = cp.lineNumber;
        }

        // Skip lines up to checkpoint
        long skipped = 0;
        while (skipped < startFrom && br.readLine() != null) {
            skipped++;
        }
        this.lineNumber = skipped;
        // Skip header only if starting from beginning and header=true
        if (this.header && this.lineNumber == 0) {
            br.readLine(); // consume header line
            this.lineNumber++;
        }
    }

    @Override
    public Object readItem() throws Exception {
        String line = br.readLine();
        if (line == null) return null;
        lineNumber++;
        return line;
    }

    @Override
    public Serializable checkpointInfo() throws Exception {
        return new ReaderCheckpoint(lineNumber);
    }

    @Override
    public void close() throws Exception {
        if (br != null) br.close();
    }
}
