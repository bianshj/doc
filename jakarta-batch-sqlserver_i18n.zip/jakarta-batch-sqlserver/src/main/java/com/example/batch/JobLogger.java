package com.example.batch;

import jakarta.batch.api.listener.JobListener;
import jakarta.inject.Named;

@Named("jobLogger")
public class JobLogger implements JobListener {
    @Override
    public void beforeJob() { System.out.println("[Job] start"); }
    @Override
    public void afterJob() { System.out.println("[Job] end"); }
}
