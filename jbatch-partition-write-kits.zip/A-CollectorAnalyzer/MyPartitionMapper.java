package demo.batch.A;

import jakarta.batch.api.partition.PartitionMapper;
import jakarta.batch.api.partition.PartitionPlan;
import jakarta.batch.api.partition.PartitionPlanImpl;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

import java.util.Properties;

/**
 * 方案A：每个分区只生产数据，不直接写最终文件。
 * 统一在 PartitionAnalyzer（管理线程，串行）写最终文件。
 */
@Dependent
@Named("myPartitionMapper")
public class MyPartitionMapper implements PartitionMapper {
    @Override
    public PartitionPlan mapPartitions() {
        int n = 3; // 分区数，可根据任务规模调整
        Properties[] props = new Properties[n];
        for (int i = 0; i < n; i++) {
            Properties p = new Properties();
            p.setProperty("partitionNumber", String.valueOf(i));
            props[i] = p;
        }
        PartitionPlanImpl plan = new PartitionPlanImpl();
        plan.setPartitions(n);
        plan.setThreads(n);
        plan.setPartitionProperties(props);
        plan.setPartitionsOverride(true); // 重启时覆盖旧计划（推荐）
        return plan;
    }
}
