package com.example.batchlock;

import java.util.Optional;

/**
 * Provider to acquire an exclusive JobLock for a given jobName.
 * Implementations: InMemoryLockProvider, DbLockProvider.
 */
public interface LockProvider {

    /**
     * Try to acquire a lock for the given job.
     * @param jobName  logical identifier to lock on (e.g., "dailyAggregation:2025-11-02")
     * @param owner    free-form owner id (hostname, pod name, etc.)
     * @param execId   optional batch execution id; may be null
     * @return Optional JobLock (present if acquired, empty if already locked)
     * @throws Exception on system/connection errors
     */
    Optional<JobLock> tryAcquire(String jobName, String owner, Long execId) throws Exception;

    /**
     * Forcefully remove a lock (admin/safety). Should be used with care.
     */
    void forceUnlock(String jobName) throws Exception;
}
