package com.example.batchlock.inmemory;

import com.example.batchlock.JobLock;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicBoolean;

final class InMemoryJobLock implements JobLock {
    private final String jobName;
    private final String owner;
    private final Long execId;
    private final AtomicBoolean held = new AtomicBoolean(true);
    private volatile Instant heartbeatAt = Instant.now();

    InMemoryJobLock(String jobName, String owner, Long execId) {
        this.jobName = jobName;
        this.owner = owner;
        this.execId = execId;
    }

    @Override
    public String jobName() { return jobName; }

    @Override
    public boolean isHeld() { return held.get(); }

    @Override
    public void heartbeat() { heartbeatAt = Instant.now(); }

    @Override
    public void unlock() {
        if (held.compareAndSet(true, false)) {
            InMemoryLockProvider.internalUnlock(jobName, this);
        }
    }
}
