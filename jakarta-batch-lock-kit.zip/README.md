# Jakarta Batch Lock Kit

A minimal, production-ready lock abstraction for **single-instance (in-memory)** and **cluster-safe (database)**
exclusive execution. Designed to prevent **multi-start** of the same Jakarta Batch job across nodes.

## Modules
- `LockProvider` / `JobLock`: small, composable interfaces
- `InMemoryLockProvider`: JVM-only, dev/single-node
- `DbLockProvider`: cluster-safe, DB-backed mutex with heartbeat & TTL cleaning
- `Heartbeat`: helper to schedule periodic heartbeats
- `SafeJobLauncher`: usage sample integrating `JobOperator`

## Quick Start (DB Lock)
1. Apply DDL for your DB from `src/main/resources/sql/*` (create table `batch_mutex`).
2. Provide a `DataSource` (JNDI, HikariCP, etc.).
3. Use `DbLockProvider` to acquire a lock, then start your batch job, send heartbeats, and finally unlock.

```java
DataSource ds = ...; // your DataSource
LockProvider provider = new DbLockProvider(ds);
Optional<JobLock> lockOpt = provider.tryAcquire("dailyAggregation:2025-11-02", "node-A", null);

if (lockOpt.isEmpty()) {
    System.out.println("Already running. Abort.");
    return;
}

try (JobLock lock = lockOpt.get()) {
    // Start job (example shown in SafeJobLauncher)
    // ... send heartbeats via Heartbeat.start(lock) ...
} // auto-unlock
```

## Jakarta Batch Integration (see `SafeJobLauncher`)
- Acquire lock → start job via `JobOperator` → on finish unlock.
- Also wire a JobListener that calls `DbLockProvider.forceUnlock(jobName)` as safety net.

## TTL Cleaning
Run the DELETE statement from the DDL file periodically (e.g., every 5–10 minutes) to clean orphaned locks
where `heartbeat_at` is stale.

## License
MIT. Do what you want, no warranty.
