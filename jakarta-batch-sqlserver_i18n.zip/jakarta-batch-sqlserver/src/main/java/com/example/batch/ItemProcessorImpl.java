package com.example.batch;

import jakarta.batch.api.chunk.ItemProcessor;
import jakarta.inject.Named;

@Named("itemProcessor")
public class ItemProcessorImpl implements ItemProcessor {
    @Override
    public Object processItem(Object o) throws Exception {
        CsvReader.Raw r = (CsvReader.Raw) o;
        if (r.id() == null || r.id().isBlank()) return null;

        String name = r.name() == null ? "" : r.name().trim();
        int price = 0;
        try { price = Integer.parseInt(r.price()); } catch (NumberFormatException ignore) {}

        return new ItemDto(r.id().trim(), name, price);
    }

    public record ItemDto(String id, String name, int price) {}
}
