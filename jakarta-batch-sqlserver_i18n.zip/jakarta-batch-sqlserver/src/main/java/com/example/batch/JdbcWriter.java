package com.example.batch;

import jakarta.batch.api.BatchProperty;
import jakarta.batch.api.chunk.AbstractItemWriter;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

@Named("jdbcWriter")
public class JdbcWriter extends AbstractItemWriter {

    @Inject @BatchProperty(name="jdbc.url")
    private String url;
    @Inject @BatchProperty(name="jdbc.user")
    private String user;
    @Inject @BatchProperty(name="jdbc.password")
    private String password;
    @Inject @BatchProperty(name="table")
    private String table;

    private Connection conn;

    @Override
    public void open(Serializable checkpoint) throws Exception {
        conn = DriverManager.getConnection(url, user, password);
        conn.setAutoCommit(false);
    }

    @Override
    public void writeItems(List<Object> items) throws Exception {
        // SQL Server の MERGE を用いた UPSERT（幂等）
        String sql = "MERGE INTO " + table + " AS t "
                   + "USING (VALUES (?, ?, ?)) AS s(id, name, price) "
                   + "ON (t.id = s.id) "
                   + "WHEN MATCHED THEN UPDATE SET t.name = s.name, t.price = s.price "
                   + "WHEN NOT MATCHED THEN INSERT (id, name, price) VALUES (s.id, s.name, s.price);";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Object obj : items) {
                ItemProcessorImpl.ItemDto dto = (ItemProcessorImpl.ItemDto) obj;
                ps.setString(1, dto.id());
                ps.setString(2, dto.name());
                ps.setInt(3, dto.price());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    @Override
    public void close() throws Exception {
        if (conn != null) conn.close();
    }
}
