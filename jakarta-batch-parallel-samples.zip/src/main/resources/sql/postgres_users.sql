CREATE TABLE IF NOT EXISTS users(
  id    bigint PRIMARY KEY,
  name  text   NOT NULL,
  email text   NOT NULL
);
CREATE TABLE IF NOT EXISTS user_profile(
  id    bigint PRIMARY KEY,
  name  text   NOT NULL,
  email text   NOT NULL
);
