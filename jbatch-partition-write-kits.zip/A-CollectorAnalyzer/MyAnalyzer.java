package demo.batch.A;

import jakarta.batch.api.partition.PartitionAnalyzer;
import jakarta.batch.runtime.BatchStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

import java.io.BufferedWriter;
import java.io.Serializable;
import java.nio.file.*;
import java.util.List;

/**
 * Analyzer 在管理线程（单线程）上执行，可安全串行写目标文件。
 */
@Dependent
@Named("myAnalyzer")
public class MyAnalyzer implements PartitionAnalyzer {
    private final Path out = Paths.get("data/out/result-A.txt");

    @Override
    public void analyzeCollectorData(Serializable data) throws Exception {
        if (data == null) return;
        @SuppressWarnings("unchecked")
        List<String> lines = (List<String>) data;
        Files.createDirectories(out.getParent());
        try (BufferedWriter w = Files.newBufferedWriter(out,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            for (String s : lines) {
                w.write(s);
                w.newLine();
            }
        }
    }

    @Override
    public void analyzeStatus(BatchStatus batchStatus, String exitStatus) {
        // 可按需记录状态
    }
}
