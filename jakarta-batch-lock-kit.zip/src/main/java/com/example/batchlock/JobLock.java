package com.example.batchlock;

import java.io.Closeable;

/**
 * Represents an acquired lock. Use try-with-resources to ensure unlock on exit.
 */
public interface JobLock extends Closeable, AutoCloseable {

    /** The job name this lock protects. */
    String jobName();

    /** Returns true if this lock is currently held by this instance. */
    boolean isHeld();

    /** Update heartbeat timestamp to indicate liveness. */
    void heartbeat() throws Exception;

    /** Release the lock immediately. Idempotent. */
    void unlock() throws Exception;

    /** Close delegates to unlock(). */
    @Override
    default void close() {
        try { unlock(); } catch (Exception ignore) {}
    }
}
