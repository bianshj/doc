-- PostgreSQL DDL for DB-backed mutex
CREATE TABLE IF NOT EXISTS batch_mutex (
  job_name     varchar(128) PRIMARY KEY,
  locked_at    timestamp      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  heartbeat_at timestamp      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  owner_node   varchar(128)   NOT NULL,
  exec_id      bigint         NULL
);

-- TTL cleanup: remove locks with stale heartbeat (10 minutes)
-- schedule this statement via cron/Quartz/etc.
-- Adjust interval as appropriate (e.g., 5x~10x your heartbeat interval)
DELETE FROM batch_mutex
 WHERE heartbeat_at < (CURRENT_TIMESTAMP - INTERVAL '10 minutes');
