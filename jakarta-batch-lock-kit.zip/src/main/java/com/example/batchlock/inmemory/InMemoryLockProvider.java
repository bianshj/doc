package com.example.batchlock.inmemory;

import com.example.batchlock.JobLock;
import com.example.batchlock.LockProvider;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JVM-local in-memory lock provider.
 * Suitable for single-node/dev only. Not safe across processes/nodes.
 */
public class InMemoryLockProvider implements LockProvider {

    private static final Map<String, InMemoryJobLock> LOCKS = new ConcurrentHashMap<>();

    @Override
    public Optional<JobLock> tryAcquire(String jobName, String owner, Long execId) {
        InMemoryJobLock lock = new InMemoryJobLock(jobName, owner, execId);
        InMemoryJobLock existing = LOCKS.putIfAbsent(jobName, lock);
        if (existing != null) return Optional.empty();
        return Optional.of(lock);
    }

    @Override
    public void forceUnlock(String jobName) {
        LOCKS.remove(jobName);
    }

    static void internalUnlock(String jobName, InMemoryJobLock lock) {
        LOCKS.remove(jobName, lock);
    }
}
