package com.example.batch;

import jakarta.batch.api.Batchlet;
import jakarta.inject.Named;

@Named("FinalizeBatchlet")
public class FinalizeBatchlet implements Batchlet {
    @Override public String process() throws Exception { return "COMPLETED"; }
    @Override public void stop() throws Exception {}
}
