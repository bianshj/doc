# Jakarta Batch 分区并发写文件 方案合集

本包整理了 **3 套可直接使用/改造的方案**：

- **A. 单写者（Collector → Analyzer）**：各分区只产出数据，统一在管理线程中串行写最终文件（*推荐，零锁*）。
- **B. 每分区写临时文件 → Reducer 合并**：并发期不共享文件，末尾单线程合并（*也推荐*）。
- **C. 并发直接写同一个文件（加锁）**：确有“实时写入”刚需时再使用。包含：JVM 内锁、OS 文件锁、分布式锁占位。

> 说明：示例采用 `jakarta.*` 包名（EE 10+）。如果你的运行时是 EE 8（WildFly 26-/Payara 5），请把包名统一改为 `javax.*`。
> **不要混用 `jakarta.*` 与 `javax.*`**。

---

## 快速选择

- **能不用并发共享写就不用**：首选 **A** 或 **B**。
- **必须实时写**：选择 **C**；单 JVM 用 **C-1**，跨 JVM/容器用 **C-3**（数据库/Redis 锁），文件系统锁 **C-2** 需验证 NFS/云盘兼容性。

---

## 项目结构
```
A-CollectorAnalyzer/
  MyPartitionMapper.java
  MyBatchlet.java
  MyCollector.java
  MyAnalyzer.java
  job-partition-collector-analyzer.xml

B-ReducerMerge/
  MyPartitionMapper.java
  MyBatchlet.java
  MyReducer.java
  job-partition-reducer-merge.xml

C-Locks/
  common/FileAppendPaths.java
  c1_jvm_lock/FileAppendLock.java
  c1_jvm_lock/MyBatchlet_JvmLock.java
  c2_os_lock/MyBatchlet_OsLock.java
  c3_dist_lock/MyBatchlet_DistLockSkeleton.java
  job-partition-locked-append.xml
```

---

## 运行要点（通用）

1. **JSL 与 `@Named` 对齐**：`<batchlet ref="...">`、`<mapper ref="...">` 等要与类上的 `@Named("...")` 完全一致；或在 JSL 中直接使用类的全限定名作为 `ref`。
2. **PartitionPlan 设置一致**：`setPartitions(n)` 与 `setPartitionProperties(new Properties[n])` 数组长度一致；`setThreads(n)` ≥ 1。
3. **Batchlet 由运行时创建**：不要在代码里 `new` 批处理 artifact。建议加 `beans.xml` 打开 CDI 发现（可选）。
4. **键名大小写完全一致**：`@BatchProperty(name="partitionNumber")` ←→ `Properties.setProperty("partitionNumber", "...")`。

---

## 编码/换行/原子写

- 统一采用 UTF-8；尽量一次写入**完整一行/块**，避免多线程混写导致“半行”。
- 需要强一致时，可采用“写临时文件 → `Files.move` 原子替换”的策略（B 方案天然支持）。

---

## License
MIT（示例用途）
