package demo.batch.C.common;

import java.nio.file.Path;
import java.nio.file.Paths;

public class FileAppendPaths {
    public static Path output() {
        return Paths.get("data/out/result-C.txt");
    }
}
