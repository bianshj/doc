package com.example.batch.chunk;

import com.example.batch.dto.UserDTO;
import jakarta.batch.api.chunk.ItemReader;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.batch.api.BatchProperty;

import java.io.Serializable;
import java.sql.*;
import javax.sql.DataSource;

@Named("UserReader")
public class UserReader implements ItemReader {

    @Inject private StepContext stepCtx;
    @Inject @BatchProperty(name = "startId") private String startIdStr;
    @Inject @BatchProperty(name = "endId")   private String endIdStr;
    @Inject private DataSource ds;

    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;
    private long lastIdRead = -1;

    @Override
    public void open(Serializable checkpoint) throws Exception {
        long startId = Long.parseLong(startIdStr);
        long endId   = Long.parseLong(endIdStr);
        if (checkpoint != null) {
            lastIdRead = (Long) checkpoint;
            startId = Math.max(startId, lastIdRead + 1);
        }
        conn = ds.getConnection();
        conn.setAutoCommit(false);
        ps = conn.prepareStatement(
            "SELECT id, name, email FROM users WHERE id BETWEEN ? AND ? ORDER BY id ASC");
        ps.setLong(1, startId);
        ps.setLong(2, endId);
        rs = ps.executeQuery();
    }

    @Override
    public Object readItem() throws Exception {
        if (rs.next()) {
            lastIdRead = rs.getLong("id");
            return new UserDTO(lastIdRead, rs.getString("name"), rs.getString("email"));
        }
        return null;
    }

    @Override public Serializable checkpointInfo() { return lastIdRead; }

    @Override public void close() throws Exception {
        try { if (rs != null) rs.close(); } catch (Exception ignore) {}
        try { if (ps != null) ps.close(); } catch (Exception ignore) {}
        try { if (conn != null) conn.close(); } catch (Exception ignore) {}
    }
}
