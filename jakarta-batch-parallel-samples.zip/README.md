# Jakarta Batch — Job-internal Parallelism Samples

This project contains **ready-to-use examples** for *job-internal parallelism* in Jakarta Batch:

1) **Partitioned Chunk** — split one step into N partitions, each runs the same chunk in parallel.  
2) **Partitioned Batchlet** — split a batchlet step into N partitions.

> These samples focus on *in-process parallelism*, not multi-start control. For **multi-start prevention across nodes** use your DB-lock kit.

## Layout
- `META-INF/batch-jobs/job-partition-chunk.xml`
- `META-INF/batch-jobs/job-partition-batchlet.xml`
- Java:
  - `mapper/UserPartitionMapper` — builds 4 partitions by ID range
  - `chunk/UserReader` / `UserProcessor` / `UserWriter` — example chunk
  - `batchlet/ExportBatchlet` — example batchlet
  - `FinalizeBatchlet` — tail step for merge/cleanup
  - `dto/UserDTO` — simple record for the reader/processor/writer

## Quick Run (concept)
```java
var op = jakarta.batch.runtime.BatchRuntime.getJobOperator();
long execId = op.start("job-partition-chunk", new java.util.Properties());
```

## Build
`pom.xml` is included to **compile** the code; the actual runtime is your Jakarta EE server.
