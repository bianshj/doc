package com.example.batch;

import jakarta.batch.api.chunk.AbstractItemWriter;
import jakarta.batch.runtime.context.JobContext;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Properties;

/**
 * Writes processed lines to output CSV in classpath 'output/output.csv' within the working dir.
 * In real-world, you'd write to an absolute path or external storage.
 */
@Named("csvWriter")
@Dependent
public class CsvItemWriter extends AbstractItemWriter {

    @Inject JobContext jobCtx;

    private FileOutputStream fos;
    private OutputStreamWriter osw;
    private BufferedWriter bw;
    private File outFile;

    @Override
    public void open(Serializable checkpoint) throws Exception {
        Properties p = jobCtx.getProperties();
        String outputPath = p.getProperty("output", "output/output.csv");
        // Resolve output to a file in working directory under target (if exists) else current dir
        File wd = new File(System.getProperty("user.dir"));
        File base = new File(wd, "target"); // typical maven build dir
        if (!base.exists()) base = wd;
        outFile = new File(base, outputPath);
        outFile.getParentFile().mkdirs();
        fos = new FileOutputStream(outFile, true);
        osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
        bw = new BufferedWriter(osw);
    }

    @Override
    public void writeItems(List<Object> items) throws Exception {
        for (Object it : items) {
            bw.write((String) it);
            bw.newLine();
        }
        bw.flush();
    }

    @Override
    public void close() throws Exception {
        if (bw != null) bw.close();
        if (osw != null) osw.close();
        if (fos != null) fos.close();
        System.out.println("Written output to: " + outFile.getAbsolutePath());
    }
}
