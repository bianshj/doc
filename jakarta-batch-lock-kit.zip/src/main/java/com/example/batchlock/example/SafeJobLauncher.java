package com.example.batchlock.example;

import com.example.batchlock.LockProvider;
import com.example.batchlock.JobLock;
import com.example.batchlock.util.Heartbeat;

import jakarta.batch.operations.JobOperator;
import jakarta.batch.runtime.BatchRuntime;

import java.util.Optional;
import java.util.Properties;

/**
 * Example: acquire lock, start Jakarta Batch job, send heartbeats, unlock on finish.
 * Note: wire a JobListener on your job as a safety net to force unlock on completion.
 */
public class SafeJobLauncher {

    private final LockProvider lockProvider;
    public SafeJobLauncher(LockProvider lockProvider) {
        this.lockProvider = lockProvider;
    }

    public void startExclusively(String jobName, Properties params, String owner) throws Exception {
        Optional<JobLock> lockOpt = lockProvider.tryAcquire(jobName, owner, null);
        if (lockOpt.isEmpty()) {
            System.out.println("Another instance is running for " + jobName + ". Abort.");
            return;
        }

        try (JobLock lock = lockOpt.get()) {
            // Start job
            JobOperator op = BatchRuntime.getJobOperator();
            long execId = op.start(jobName, params);
            System.out.println("Started job " + jobName + " execId=" + execId);

            // Start heartbeat every 60s
            Runnable stop = Heartbeat.start(lock, 60);

            // TODO: wait for completion or rely on JobListener to forceUnlock
            // stop.run(); // when job completes

        } // auto-unlock via close()
    }
}
