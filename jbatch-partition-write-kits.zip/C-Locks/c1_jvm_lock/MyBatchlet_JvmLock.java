package demo.batch.C.c1_jvm_lock;

import demo.batch.C.common.FileAppendPaths;
import jakarta.batch.api.AbstractBatchlet;
import jakarta.batch.api.BatchProperty;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.BufferedWriter;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

/**
 * 方案C-1：JVM 内锁。适合单 JVM 多分区线程。
 */
@Dependent
@Named("myBatchlet_JvmLock")
public class MyBatchlet_JvmLock extends AbstractBatchlet {

    @Inject @BatchProperty(name = "partitionNumber")
    private String partNo;

    @Inject
    private FileAppendLock fileLock;

    @Override
    public String process() throws Exception {
        List<String> lines = Arrays.asList(
                "part=" + partNo + ", line=1",
                "part=" + partNo + ", line=2"
        );
        fileLock.withLockThrowing(() -> {
            var out = FileAppendPaths.output();
            Files.createDirectories(out.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(out,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                for (String s : lines) {
                    w.write(s);
                    w.newLine();
                }
            } catch (java.io.IOException e) {
                throw new UncheckedIOException(e);
            }
            return null;
        });
        return "COMPLETED";
    }
}
