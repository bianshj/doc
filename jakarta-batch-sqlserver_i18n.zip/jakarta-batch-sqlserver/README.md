# Jakarta Batch（SQL Server版）デモ

このプロジェクトは **Jakarta Batch (JSR 352)** を **JBeret SE** で実行する最小構成のデモです。
入力CSVを読み込み、Processorで整形し、Writerで **SQL Server** に **幂等(UPSERT/MERGE)** で書き込みます。

## 構成
- Job XML: `src/main/resources/META-INF/batch-jobs/import-items.xml`
- Reader: `CsvReader`（CSV 1件ずつ読み、checkpointは行番号）
- Processor: `ItemProcessorImpl`（検証/整形、nullでフィルタ）
- Writer: `JdbcWriter`（SQL ServerのMERGEでUPSERT）
- Listener: `JobLogger`
- 起動: `BatchMain`（`JobOperator.start`）

## 必要条件
- JDK 17+
- Maven 3.8+
- SQL Server（ローカルでもDockerでも可）
- テーブル作成（例）
```sql
CREATE TABLE dbo.Items(
  id   VARCHAR(64) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  price INT NOT NULL
);
```

## ビルド & 実行
```bash
mvn -q -f pom.xml clean package
mvn -q exec:java
```
※ 実行前に `BatchMain` 内の JDBC 接続情報をあなたの環境に合わせて編集してください。
