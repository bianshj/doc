package com.example.batchlock.db;

import com.example.batchlock.JobLock;

import java.sql.Connection;
import java.sql.PreparedStatement;

/** Holds a DB row as the mutex. */
final class DbJobLock implements JobLock {
    private final Connection conn;
    private final String jobName;
    private volatile boolean held = true;

    DbJobLock(Connection conn, String jobName) {
        this.conn = conn;
        this.jobName = jobName;
    }

    @Override
    public String jobName() { return jobName; }

    @Override
    public boolean isHeld() { return held; }

    @Override
    public void heartbeat() throws Exception {
        if (!held) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE batch_mutex SET heartbeat_at=CURRENT_TIMESTAMP WHERE job_name=?")) {
            ps.setString(1, jobName);
            ps.executeUpdate();
        }
    }

    @Override
    public void unlock() throws Exception {
        if (!held) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM batch_mutex WHERE job_name=?")) {
            ps.setString(1, jobName);
            ps.executeUpdate();
        } finally {
            held = false;
            try { conn.close(); } catch (Exception ignore) {}
        }
    }
}
