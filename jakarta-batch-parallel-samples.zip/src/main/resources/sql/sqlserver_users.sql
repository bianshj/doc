IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='users')
BEGIN
  CREATE TABLE dbo.users(
    id    BIGINT NOT NULL PRIMARY KEY,
    name  NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL
  );
END
GO
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='user_profile')
BEGIN
  CREATE TABLE dbo.user_profile(
    id    BIGINT NOT NULL PRIMARY KEY,
    name  NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL
  );
END
GO
