package demo.batch.C.c1_jvm_lock;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 单 JVM 内的公平锁，保护对同一个文件的临界区访问。
 */
@ApplicationScoped
public class FileAppendLock {
    private final ReentrantLock lock = new ReentrantLock(true);

    public <T> T withLockThrowing(ThrowingSupplier<T> block) throws Exception {
        boolean ok = false;
        try {
            ok = lock.tryLock(5, TimeUnit.SECONDS);
            if (!ok) throw new IllegalStateException("append lock timeout");
            return block.get();
        } finally {
            if (ok) lock.unlock();
        }
    }

    @FunctionalInterface
    public interface ThrowingSupplier<T> {
        T get() throws Exception;
    }
}
