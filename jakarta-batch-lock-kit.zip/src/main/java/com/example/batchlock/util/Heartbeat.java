package com.example.batchlock.util;

import com.example.batchlock.JobLock;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Simple helper to periodically call JobLock.heartbeat().
 */
public final class Heartbeat {

    private static final ScheduledExecutorService SES =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "batch-heartbeat"); t.setDaemon(true); return t;
            });

    private Heartbeat() {}

    /**
     * Start sending heartbeats every intervalSeconds.
     * @return a Runnable you can call to stop scheduling (cancels the task).
     */
    public static Runnable start(JobLock lock, int intervalSeconds) {
        var handle = SES.scheduleAtFixedRate(() -> {
            try { lock.heartbeat(); } catch (Exception ignore) {}
        }, intervalSeconds, intervalSeconds, TimeUnit.SECONDS);

        return () -> handle.cancel(false);
    }
}
