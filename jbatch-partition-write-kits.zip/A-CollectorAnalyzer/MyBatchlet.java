package demo.batch.A;

import jakarta.batch.api.AbstractBatchlet;
import jakarta.batch.api.BatchProperty;
import jakarta.batch.runtime.context.StepContext;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.util.ArrayList;
import java.util.List;

/**
 * 每个分区线程里，仅生成要写入的内容，存入 StepContext 的 transientUserData，
 * 由 Collector 收集并交给 Analyzer 串行写入。
 */
@Dependent
@Named("myBatchlet")
public class MyBatchlet extends AbstractBatchlet {

    @Inject @BatchProperty(name = "partitionNumber")
    private String partNo;

    @Inject
    private StepContext stepCtx;

    @Override
    public String process() throws Exception {
        int idx = Integer.parseInt(partNo);
        List<String> lines = new ArrayList<>();
        lines.add("part=" + idx + ", line=1");
        lines.add("part=" + idx + ", line=2");
        // 把要写入的内容放入 transientUserData（Collector 将读取）
        stepCtx.setTransientUserData(lines);
        return "COMPLETED";
    }
}
