package com.example.batch.chunk;

import com.example.batch.dto.UserDTO;
import jakarta.batch.api.chunk.ItemProcessor;
import jakarta.inject.Named;

@Named("UserProcessor")
public class UserProcessor implements ItemProcessor {
    @Override
    public Object processItem(Object item) throws Exception {
        UserDTO u = (UserDTO) item;
        return new UserDTO(u.id(), u.name().trim(), u.email().toLowerCase());
    }
}
