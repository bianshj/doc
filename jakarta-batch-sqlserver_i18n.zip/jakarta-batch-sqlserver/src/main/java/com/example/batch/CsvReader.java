package com.example.batch;

import jakarta.batch.api.BatchProperty;
import jakarta.batch.api.chunk.AbstractItemReader;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;

@Named("csvReader")
public class CsvReader extends AbstractItemReader {

    @Inject @BatchProperty(name="input")
    private String inputPath;

    @Inject @BatchProperty(name="chunkSize")
    private String chunkSizeStr;

    private BufferedReader br;
    private long lineNo = 0;
    private Deque<Raw> buffer = new ArrayDeque<>();
    private int chunkSize = 200;

    @Override
    public void open(Serializable checkpoint) throws Exception {
        if (chunkSizeStr != null) {
            try { chunkSize = Integer.parseInt(chunkSizeStr); } catch (NumberFormatException ignore) {}
        }
        br = new BufferedReader(new InputStreamReader(new FileInputStream(inputPath), StandardCharsets.UTF_8));
        if (checkpoint != null) {
            lineNo = (Long) checkpoint;
            for (long i=0; i<lineNo; i++) { if (br.readLine() == null) break; }
        }
        fillBuffer();
    }

    private void fillBuffer() throws Exception {
        while (buffer.size() < chunkSize) {
            String line = br.readLine();
            if (line == null) break;
            lineNo++;
            if (lineNo == 1 && line.startsWith("id,")) continue;
            String[] a = line.split(",");
            if (a.length < 3) continue;
            buffer.add(new Raw(a[0].trim(), a[1].trim(), a[2].trim()));
        }
    }

    @Override
    public Object readItem() throws Exception {
        if (buffer.isEmpty()) {
            fillBuffer();
            if (buffer.isEmpty()) return null;
        }
        return buffer.removeFirst();
    }

    @Override
    public Serializable checkpointInfo() { return lineNo; }

    @Override
    public void close() throws Exception { if (br != null) br.close(); }

    public record Raw(String id, String name, String price) {}
}
