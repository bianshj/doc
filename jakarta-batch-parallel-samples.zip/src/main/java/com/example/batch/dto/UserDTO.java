package com.example.batch.dto;
public record UserDTO(long id, String name, String email) {}
