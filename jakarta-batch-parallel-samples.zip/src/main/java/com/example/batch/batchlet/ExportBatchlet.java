package com.example.batch.batchlet;

import jakarta.batch.api.Batchlet;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("ExportBatchlet")
public class ExportBatchlet implements Batchlet {
    @Inject private StepContext stepCtx;
    @Override
    public String process() throws Exception {
        String start = stepCtx.getProperties().getProperty("startId");
        String end   = stepCtx.getProperties().getProperty("endId");
        // Export logic per range [start..end]
        return "COMPLETED";
    }
    @Override public void stop() throws Exception {}
}
