package demo.batch.C.c2_os_lock;

import demo.batch.C.common.FileAppendPaths;
import jakarta.batch.api.AbstractBatchlet;
import jakarta.batch.api.BatchProperty;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

/**
 * 方案C-2：OS 文件锁（FileChannel.lock/tryLock）。可跨进程；在 NFS/云盘上需验证兼容性。
 */
@Dependent
@Named("myBatchlet_OsLock")
public class MyBatchlet_OsLock extends AbstractBatchlet {

    @Inject @BatchProperty(name = "partitionNumber")
    private String partNo;

    @Override
    public String process() throws Exception {
        List<String> lines = Arrays.asList(
                "part=" + partNo + ", line=1",
                "part=" + partNo + ", line=2"
        );
        var out = FileAppendPaths.output();
        java.nio.file.Files.createDirectories(out.getParent());
        try (FileChannel ch = FileChannel.open(out,
                StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND)) {
            try (java.nio.channels.FileLock fl = ch.lock()) {
                for (String s : lines) {
                    byte[] b = (s + System.lineSeparator()).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    ch.write(ByteBuffer.wrap(b));
                }
            }
        }
        return "COMPLETED";
    }
}
