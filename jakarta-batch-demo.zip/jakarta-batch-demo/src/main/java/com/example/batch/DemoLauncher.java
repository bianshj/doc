package com.example.batch;

import jakarta.batch.operations.JobOperator;
import jakarta.batch.runtime.BatchRuntime;
import java.util.Properties;

public class DemoLauncher {
    public static void main(String[] args) {
        String jobName = args.length > 0 ? args[0] : "csvJob";
        Properties props = new Properties();
        // allow overriding via system properties or args in real cases
        JobOperator jobOperator = BatchRuntime.getJobOperator();
        long execId = jobOperator.start(jobName, props);
        System.out.println("Started job '" + jobName + "' with executionId=" + execId);
    }
}
