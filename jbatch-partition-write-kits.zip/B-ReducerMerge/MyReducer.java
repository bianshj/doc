package demo.batch.B;

import jakarta.batch.api.partition.PartitionReducer;
import jakarta.batch.runtime.context.StepContext;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;

/**
 * 所有分区完成后，Reducer 在单线程中合并 tmp → result-B.txt
 * 分区数可从上下文或配置获取，这里示例简单写死；实际可把分区数作为作业属性传入。
 */
@Dependent
@Named("myReducer")
public class MyReducer implements PartitionReducer {

    @Inject
    private StepContext stepCtx;

    private int partitions = 3; // 示例写死；生产中可从 Mapper/属性传入

    @Override public void beginPartitionedStep() { }

    @Override public void beforePartitionedStepCompletion() { }

    @Override
    public void afterPartitionedStepCompletion(jakarta.batch.api.partition.PartitionStatus status) throws Exception {
        Path out = Paths.get("data/out/result-B.txt");
        Files.createDirectories(out.getParent());
        try (BufferedWriter w = Files.newBufferedWriter(out,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
            for (int i = 0; i < partitions; i++) {
                Path tmp = Paths.get("data/out/tmp/result_part_" + i + ".txt");
                if (Files.exists(tmp)) {
                    try (Stream<String> lines = Files.lines(tmp)) {
                        lines.forEach(line -> {
                            try { w.write(line); w.newLine(); } catch (IOException e) { throw new RuntimeException(e); }
                        });
                    }
                }
            }
        }
        // 可选：清理 tmp
        // for (int i = 0; i < partitions; i++) Files.deleteIfExists(Paths.get("data/out/tmp/result_part_" + i + ".txt"));
    }

    @Override public void rollbackPartitionedStep() { /* 失败时做清理 */ }
}
